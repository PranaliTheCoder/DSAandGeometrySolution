#include <iostream>
#include <vector>
#include <tuple>
#include <climits>
#include "StockMarketExample.h"

//////////////////////////////////////////////////////////////////////////
//Purpose: Finds the consecutive sequence of days with the maximum sum of profits.
// Algorithm to efficiently compute maximum subarray sum in O(n) time.
// Input:
// iDailyReturns - Vector of daily profit or loss values (can be positive, negative, or zero).
// Output:
// Returns a tuple with three values:
// oStartDay - 1-based index of the first day in the maximum profit sequence.
// oEndDay   - 1-based index of the last day in the maximum profit sequence.
// oMaxProfitSum - The maximum profit sum over that consecutive sequence.
//////////////////////////////////////////////////////////////////////////

std::tuple<int, int, int> FindMaxConsecutiveProfitPeriod(const std::vector<int>& iDailyReturns)
{
	// Initialize maximum profit sum with smallest integer to ensure any sum beats it.
	int aMaxProfitSum = INT_MIN;

	// Running sum of the current consecutive subarray under consideration.
	int aCurrentProfitSum = 0;

	// Index marking the potential start of a new subarray when current sum resets.
	int aPotentialStartIndex = 0;

	// Indices tracking the start and end of the best (max profit) subarray found so far.
	int aMaxProfitStartIndex = 0;
	int aMaxProfitEndIndex = 0;

	// Iterate through all daily returns using index 'aCurrentDayIndex'
	for (int aCurrentDayIndex = 0; aCurrentDayIndex < static_cast<int>(iDailyReturns.size()); ++aCurrentDayIndex)
	{
		// Add today's return to the running sum.
		aCurrentProfitSum += iDailyReturns[aCurrentDayIndex];

		// If current running sum is better than max found so far, update max and indices.
		if (aCurrentProfitSum > aMaxProfitSum)
		{
			aMaxProfitSum = aCurrentProfitSum;
			aMaxProfitStartIndex = aPotentialStartIndex;
			aMaxProfitEndIndex = aCurrentDayIndex;
		}

		// If running sum becomes negative, discard it and start fresh from next day.
		// Negative sums would only reduce potential profit, so reset.
		if (aCurrentProfitSum < 0)
		{
			aCurrentProfitSum = 0;
			aPotentialStartIndex = aCurrentDayIndex + 1;
		}
	}

	// Convert zero-based indices to one-based days for output clarity.
	int oStartDay = aMaxProfitStartIndex + 1;
	int oEndDay = aMaxProfitEndIndex + 1;
	int oMaxProfitSum = aMaxProfitSum;

	return std::make_tuple(oStartDay, oEndDay, oMaxProfitSum);
}

//int main()
//{
//	// Input vector of daily returns for 20 days, including both profits and losses.
//	std::vector<int> aDailyReturns = {-20, -30, -40, -50, -60, -70, -80, -90, -91, -100,-121, -340, -500, -600, -650, -654, -743, -960, -1000, -1110};
//
//	int oStartDay = 0;
//	int oEndDay = 0;
//	int oMaxProfitSum = 0;
//
//	// Compute the maximum profit period.
//	std::tie(oStartDay, oEndDay, oMaxProfitSum) = FindMaxConsecutiveProfitPeriod(aDailyReturns);
//
//	// Display the results.
//	std::cout << "Maximum profit of Rs." << oMaxProfitSum
//		<< " Achieved from day " << oStartDay
//		<< " To day " << oEndDay << std::endl;
//
//	return 0;
//}
