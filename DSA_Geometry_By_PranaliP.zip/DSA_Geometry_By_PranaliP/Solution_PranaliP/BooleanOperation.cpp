﻿// BooleanOperation.cpp
#include "BooleanOperation.h"
using namespace std;

// Build and free circular linked lists
static Node* BuildCircularList(const vector<Point>& inputContour)
{
	if (inputContour.empty()) return nullptr;
	Node* aHead = new Node(inputContour[0]);
	Node* aCurr = aHead;
	for (size_t aIndex = 1; aIndex < inputContour.size(); ++aIndex)
	{
		aCurr->next = new Node(inputContour[aIndex]);
		aCurr = aCurr->next;
	}
	aCurr->next = aHead;
	return aHead;
}

static void FreeCircularList(Node* inputHead)
{
	if (!inputHead) return;
	Node* aCurr = inputHead->next;
	while (aCurr != inputHead)
	{
		Node* aTemp = aCurr;
		aCurr = aCurr->next;
		delete aTemp;
	}
	delete inputHead;
}

// Edge–edge intersection test
static bool AreEdgesIntersecting(const Point& inputPt1, const Point& inputPt2,
	const Point& inputPt3, const Point& inputPt4,
	Point& oIntersect)
{
	if (max(inputPt1.x, inputPt2.x) < min(inputPt3.x, inputPt4.x) ||
		max(inputPt3.x, inputPt4.x) < min(inputPt1.x, inputPt2.x) ||
		max(inputPt1.y, inputPt2.y) < min(inputPt3.y, inputPt4.y) ||
		max(inputPt3.y, inputPt4.y) < min(inputPt1.y, inputPt2.y))
		return false;

	double aDx1 = inputPt2.x - inputPt1.x;
	double aDy1 = inputPt2.y - inputPt1.y;
	double aDx2 = inputPt4.x - inputPt3.x;
	double aDy2 = inputPt4.y - inputPt3.y;
	double aDet = aDx1 * aDy2 - aDx2 * aDy1;
	double aEps = 1e-12 * max(hypot(aDx1, aDy1), hypot(aDx2, aDy2));
	if (abs(aDet) < aEps) return false;

	double aInvDet = 1.0 / aDet;
	double aT = (aDx2 * (inputPt1.y - inputPt3.y) - aDy2 * (inputPt1.x - inputPt3.x)) * aInvDet;
	double aU = (aDx1 * (inputPt1.y - inputPt3.y) - aDy1 * (inputPt1.x - inputPt3.x)) * aInvDet;
	if (aT >= 0.0 && aT <= 1.0 && aU >= 0.0 && aU <= 1.0)
	{
		oIntersect.x = inputPt1.x + aT * aDx1;
		oIntersect.y = inputPt1.y + aT * aDy1;
		return true;
	}
	return false;
}

// Find and insert intersections
static void FindAllIntersections(Node* inputListA, Node* inputListB)
{
	struct Intersection { Node* a; Node* b; Point pt; double t; };
	vector<Intersection> aIntersections;

	if (inputListA && inputListB) 
	{
		Node* aNodeA = inputListA;
		do 
		{
			Node* aNodeB = inputListB;
			do 
			{
				Point aPt;
				if (AreEdgesIntersecting(aNodeA->pt, aNodeA->next->pt,
					aNodeB->pt, aNodeB->next->pt, aPt))
				{
					double aDx = aNodeA->next->pt.x - aNodeA->pt.x;
					double aDy = aNodeA->next->pt.y - aNodeA->pt.y;
					double aParam = (aDx != 0.0)
						? (aPt.x - aNodeA->pt.x) / aDx
						: (aPt.y - aNodeA->pt.y) / aDy;
					aIntersections.push_back({ aNodeA, aNodeB, aPt, aParam });
				}
				aNodeB = aNodeB->next;
			} while (aNodeB != inputListB);
			aNodeA = aNodeA->next;
		} while (aNodeA != inputListA);
	}

	sort(aIntersections.begin(), aIntersections.end(),
		[](const Intersection& L, const Intersection& R) { return L.t < R.t; });

	for (const auto& I : aIntersections)
	{
		Node* aNodeA = new Node(I.pt);
		Node* aNodeB = new Node(I.pt);
		aNodeA->mIsIntersection = aNodeB->mIsIntersection = true;
		aNodeA->mNeighbor = aNodeB;
		aNodeB->mNeighbor = aNodeA;
		// Insert
		aNodeA->next = I.a->next;
		I.a->next = aNodeA;
		aNodeB->next = I.b->next;
		I.b->next = aNodeB;
	}
}

// Classify entry/exit at intersections
static void ClassifyAllIntersections(Node* inputHead, bool inputIsEntry)
{
	Node* aCurr = inputHead;
	bool aEntryFlag = inputIsEntry;
	do 
	{
		if (aCurr->mIsIntersection)
		{
			aCurr->mIsEntry = aEntryFlag;
			aEntryFlag = !aEntryFlag;
		}
		aCurr = aCurr->next;
	} while (aCurr != inputHead);
}

// Trace one contour
static vector<Point> TraceResultContour(Node* inputStart, bool inputIsUnion)
{
	vector<Point> oContour;
	Node* aCurr = inputStart;
	bool aForward = true;
	do {
		aCurr->mVisited = true;
		oContour.push_back(aCurr->pt);
		if (aCurr->mIsIntersection)
		{
			aForward = (aCurr->mIsEntry == inputIsUnion);
			aCurr = aForward ? aCurr->next : aCurr->mNeighbor->next;
		}
		else
		{
			aCurr = aCurr->next;
		}
	} while (aCurr != inputStart && !aCurr->mVisited);
	return oContour;
}

// Check clockwise orientation
static bool IsPolygonClockwise(const vector<Point>& inputContour)
{
	double aSum = 0;
	for (size_t aIdx = 0; aIdx < inputContour.size(); ++aIdx)
	{
		const auto& aP1 = inputContour[aIdx];
		const auto& aP2 = inputContour[(aIdx + 1) % inputContour.size()];
		aSum += (aP2.x - aP1.x) * (aP2.y + aP1.y);
	}
	return aSum > 0;
}

// Ensure winding order
void EnsureWindingOrder(Polygon& inputPoly)
{
	if (!IsPolygonClockwise(inputPoly.outer))
		reverse(inputPoly.outer.begin(), inputPoly.outer.end());
	for (auto& aHole : inputPoly.mHoles)
		if (IsPolygonClockwise(aHole))
			reverse(aHole.begin(), aHole.end());
}

// Perform union of two polygons
vector<vector<Point>> PerformUnion(const Polygon& inputA, const Polygon& inputB)
{
	Polygon aPolyA = inputA;
	Polygon aPolyB = inputB;
	EnsureWindingOrder(aPolyA);
	EnsureWindingOrder(aPolyB);

	vector<Node*> aListsA{ BuildCircularList(aPolyA.outer) };
	for (const auto& aHole : aPolyA.mHoles) aListsA.push_back(BuildCircularList(aHole));
	vector<Node*> aListsB{ BuildCircularList(aPolyB.outer) };
	for (const auto& aHole : aPolyB.mHoles) aListsB.push_back(BuildCircularList(aHole));

	for (auto* aListA : aListsA)
		for (auto* aListB : aListsB)
			FindAllIntersections(aListA, aListB);

	for (size_t aIdx = 0; aIdx < aListsA.size(); ++aIdx)
		ClassifyAllIntersections(aListsA[aIdx], (aIdx == 0));
	for (size_t aIdx = 0; aIdx < aListsB.size(); ++aIdx)
		ClassifyAllIntersections(aListsB[aIdx], (aIdx != 0));

	vector<vector<Point>> oResults;
	for (auto* aList : aListsA)
	{
		for (Node* aNode = aList; ; aNode = aNode->next)
		{
			if (aNode->mIsIntersection && !aNode->mVisited)
			{
				auto oRing = TraceResultContour(aNode, true);
				if (oRing.size() >= 3) oResults.push_back(oRing);
			}
			if (aNode->next == aList) break;
		}
	}

	for (auto* aList : aListsA) FreeCircularList(aList);
	for (auto* aList : aListsB) FreeCircularList(aList);

	return oResults;
}

// Perform subtraction of B from A
vector<vector<Point>> PerformSubtract(const Polygon& inputA, const Polygon& inputB)
{
	Polygon aPolyA = inputA;
	Polygon aPolyB = inputB;
	EnsureWindingOrder(aPolyA);
	EnsureWindingOrder(aPolyB);

	vector<Node*> aListsA{ BuildCircularList(aPolyA.outer) };
	for (const auto& aHole : aPolyA.mHoles) aListsA.push_back(BuildCircularList(aHole));
	vector<Node*> aListsB{ BuildCircularList(aPolyB.outer) };
	for (const auto& aHole : aPolyB.mHoles) aListsB.push_back(BuildCircularList(aHole));

	for (auto* aListA : aListsA)
		for (auto* aListB : aListsB)
			FindAllIntersections(aListA, aListB);

	// Classification: outer of A entry, outer of B exit
	for (size_t aIdx = 0; aIdx < aListsA.size(); ++aIdx)
		ClassifyAllIntersections(aListsA[aIdx], (aIdx == 0));
	for (size_t aIdx = 0; aIdx < aListsB.size(); ++aIdx)
		ClassifyAllIntersections(aListsB[aIdx], (aIdx != 0));

	vector<vector<Point>> aAll;
	for (auto* aList : aListsA)
	{
		for (Node* aNode = aList; ; aNode = aNode->next)
		{
			if (aNode->mIsIntersection && !aNode->mVisited)
			{
				auto oRing = TraceResultContour(aNode, false);
				if (oRing.size() >= 3) aAll.push_back(oRing);
			}
			if (aNode->next == aList) break;
		}
	}

	for (auto* aList : aListsA) FreeCircularList(aList);
	for (auto* aList : aListsB) FreeCircularList(aList);


	vector<vector<Point>> oResults;
	for (auto& ring : aAll)
		if (IsPolygonClockwise(ring))
			oResults.push_back(ring);

	return oResults;
}

void PrintResults(const vector<vector<Point>>& inputResults)
{
	for (size_t i = 0; i < inputResults.size(); ++i)
	{
		cout << "Contour " << (i + 1) << ":\n";
		for (auto& pt : inputResults[i])
			cout << "(" << pt.x << ", " << pt.y << ") ";
		cout << "\n\n";
	}
}


