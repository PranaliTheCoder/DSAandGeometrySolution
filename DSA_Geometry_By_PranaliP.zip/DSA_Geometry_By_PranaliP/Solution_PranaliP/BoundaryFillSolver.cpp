// BoundaryFillSolver.cpp
#include "BoundaryFillSolver.h"
#include <iostream>
#include <vector>
#include <algorithm>

BoundaryFillSolver::BoundaryFillSolver()
{

}
//Fill between paired runs in aLine with aBoundary
static void FillBetweenRuns(std::string& aLine,const std::vector<std::pair<int, int>>& aRuns,char aBoundary)
{
	// Pair runs as (run0, run1), (run2, run3), ...
	for (size_t i = 0; i + 1 < aRuns.size(); i += 2)
	{
		int aEndFirst = aRuns[i].second;
		int aStartNext = aRuns[i + 1].first;
		// Fill strictly between those two boundary runs
		for (int aPos = aEndFirst + 1; aPos < aStartNext; ++aPos)
		{
			if (aLine[aPos] == ' ')
				aLine[aPos] = aBoundary;
		}
	}
}

// X/A/Z and fill closed spans
void BoundaryFillSolver::FillRow(int iRowIndex)
{
	for (char aBoundary : { 'A','X','Z' })
	{
		std::vector<std::pair<int, int>> aRuns;
		bool aInRun = false;
		int aRunStart = 0;

		for (int aCol = 0; aCol < mColCount; ++aCol)
		{
			if (mGrid[iRowIndex][aCol] == aBoundary)
			{
				if (!aInRun)
				{
					aInRun = true;
					aRunStart = aCol;
				}
			}
			else if (aInRun)
			{
				aRuns.emplace_back(aRunStart, aCol - 1);
				aInRun = false;
			}
		}
		if (aInRun)
			aRuns.emplace_back(aRunStart, mColCount - 1);

		
		if (aRuns.size() >= 2)
			FillBetweenRuns(mGrid[iRowIndex], aRuns, aBoundary);
	}
}

// Scan column aColIndex for runs of X/A/Z and fill closed spans
void BoundaryFillSolver::FillColumn(int iColIndex)
{
	// Extract the column into a temporary string
	std::string aColStr(mRowCount, ' ');
	for (int aRow = 0; aRow < mRowCount; ++aRow)
		aColStr[aRow] = mGrid[aRow][iColIndex];

	// Identify and fill runs in the column string
	for (char aBoundary : { 'X', 'A', 'Z' })
	{
		std::vector<std::pair<int, int>> aRuns;
		bool aInRun = false;
		int aRunStart = 0;

		for (int aRow = 0; aRow < mRowCount; ++aRow)
		{
			if (aColStr[aRow] == aBoundary)
			{
				if (!aInRun)
				{
					aInRun = true;
					aRunStart = aRow;
				}
			}
			else if (aInRun)
			{
				aRuns.emplace_back(aRunStart, aRow - 1);
				aInRun = false;
			}
		}
		if (aInRun)
			aRuns.emplace_back(aRunStart, mRowCount - 1);

		if (aRuns.size() >= 2)
			FillBetweenRuns(aColStr, aRuns, aBoundary);
	}

	for (int aRow = 0; aRow < mRowCount; ++aRow)
		mGrid[aRow][iColIndex] = aColStr[aRow];
}


void BoundaryFillSolver::FillRowOrColumnBasedOnUserInput(const std::string& iMode, int iNumber)
{
	std::string aMode = iMode;
	std::transform(aMode.begin(), aMode.end(), aMode.begin(),
		[](unsigned char c) { return std::tolower(c); });

	if (aMode == "r" || aMode == "row")
	{
		int aRowIndex = iNumber - 1;
		if (aRowIndex < 0 || aRowIndex >= mRowCount)
		{
			std::cout << "Invalid Row Number Entered.\n";
			return;
		}
		FillRow(aRowIndex);
	}
	else if (aMode == "c" || aMode == "column")
	{
		int aColIndex = iNumber - 1;
		if (aColIndex < 0 || aColIndex >= mColCount)
		{
			std::cout << "Invalid Column Entered.\n";
			return;
		}
		FillColumn(aColIndex);
	}
	else
	{
		std::cout << "Invalid mode. Please enter 'r' or 'c'.\n";
	}
}

// Print the Grid
void BoundaryFillSolver::DisplayGrid() const
{
	for (const auto& aLine : mGrid)
		std::cout << aLine << "\n";
}
