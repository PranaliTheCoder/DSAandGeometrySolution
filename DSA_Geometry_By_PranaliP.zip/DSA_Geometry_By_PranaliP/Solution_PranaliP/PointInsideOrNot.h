#pragma once
#ifndef POLYGON_CLASSIFIER_H
#define POLYGON_CLASSIFIER_H

#include <vector>
#include <utility>

using Point1 = std::pair<double, double>;
using Polygone = std::vector<Point1>;

class PolygonClassifier 
{
public:
	void SetOuterPolygon(const Polygone& iOuter);
	void AddHole(const Polygone& iHole);
	bool IsPointInside(const Point1& iPoint) const;

private:
	Polygone mOuterPolygon;
	std::vector<Polygone> mHoles;
	bool IsPointInPolygon(const Point1& iPoint, const Polygone& iPoly) const;

};

#endif // POLYGON_CLASSIFIER_H
