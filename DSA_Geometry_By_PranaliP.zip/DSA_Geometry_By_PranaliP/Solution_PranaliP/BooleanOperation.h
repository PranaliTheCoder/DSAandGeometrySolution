﻿#ifndef BOOLEAN_OPERATION_H
#define BOOLEAN_OPERATION_H

#include <vector>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <stack>

struct Point
{
	double x, y;
	Point(double iX = 0, double iY = 0) : x(iX), y(iY) {}
};

struct Node
{
	Point pt;
	bool mIsIntersection;
	bool mIsEntry;
	bool mVisited;
	Node* next;
	Node* mNeighbor;

	Node(const Point& inputP)
		: pt(inputP)
		, mIsIntersection(false)
		, mIsEntry(false)
		, mVisited(false)
		, next(nullptr)
		, mNeighbor(nullptr)
	{}
};

class Polygon
{
public:
	std::vector<Point> outer;
	std::vector<std::vector<Point>> mHoles;

	void AddHole(const std::vector<Point>& inputHole)
	{
		mHoles.push_back(inputHole);
	}
};

std::vector<std::vector<Point>> PerformUnion(const Polygon& inputA, const Polygon& inputB);
std::vector<std::vector<Point>> PerformSubtract(const Polygon& inputA, const Polygon& inputB);
void EnsureWindingOrder(Polygon& inputPoly);
void PrintResults(const std::vector<std::vector<Point>>& inputResults);

#endif // BOOLEAN_OPERATION_H
