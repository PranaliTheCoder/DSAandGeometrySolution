#pragma once
#ifndef MAZESOLVER_H
#define MAZESOLVER_H

#include <vector>
#include <queue>
#include <utility>
#include <algorithm>
#include <climits>

class MazeSolver
{
public:
	MazeSolver(const std::vector<std::vector<int>>& iMazeGrid, std::pair<int, int> iGoalPosition);

	bool FindOptimalPathUsingBFS(std::pair<int, int> iStartPosition, std::pair<int, int> iGoalPosition, std::vector<std::pair<int, int>>& oPath);

	bool FindOptimalPathUsingAStar(std::pair<int, int> iStartPosition, std::pair<int, int> iGoalPosition, std::vector<std::pair<int, int>>& oPath);

	void PrintPath(const std::vector<std::pair<int, int>>& iPath);

private:
	std::vector<std::vector<int>>mMazeGrid; // Maze: 0=free, 1=blocked
	int mRowCount;	// No. of rows
	int mColCount;	// No. of columns
	std::pair<int, int>mGoalPosition;	//Goal cell
	std::vector<std::vector<int>>mHeuristicTable; // Precomputed HeuristicTable

	bool IsCellValid(int aRow, int aCol, const std::vector<std::vector<bool>>& iVisited) const;

	bool IsCellBlocked(int aRow, int aCol) const;

	void ReconstructThePath(std::pair<int, int> iStartPos, std::pair<int, int> iCurrentPos,
		const std::vector<std::vector<std::pair<int, int>>>& iParentOf,
		std::vector<std::pair<int, int>>& oPath) const;

};


#endif // MAZESOLVER_H
