#include "ToolPath.h"
#include <algorithm>

// Point-in-polygon test using ray casting
bool IsPointInsidePolygon(const ToolPathPoint& iPoint, const BluePolygon& iPolygon)
{
	int aCrossingCount = 0;
	int aNumVertices = (int)iPolygon.size();
	for (int aIndex = 0; aIndex < aNumVertices; ++aIndex)
	{
		ToolPathPoint aVertexA = iPolygon[aIndex];
		ToolPathPoint aVertexB = iPolygon[(aIndex + 1) % aNumVertices];

		if (((aVertexA.y > iPoint.y) != (aVertexB.y > iPoint.y)) &&
			(iPoint.x < (aVertexB.x - aVertexA.x) * (iPoint.y - aVertexA.y) / (aVertexB.y - aVertexA.y + 1e-9) + aVertexA.x))
		{
			aCrossingCount++;
		}
	}
	return (aCrossingCount % 2) == 1;
}

// Check if all corners of the tool square are inside the region polygon
bool AreAllToolCornersInsideRegion(const ToolPathPoint& iToolCenter, double iToolSize, const BluePolygon& iRegion)
{
	double aHalfToolSize = iToolSize / 2.0;
	std::vector<ToolPathPoint> aToolCorners =
	{
		{iToolCenter.x - aHalfToolSize, iToolCenter.y - aHalfToolSize},
		{iToolCenter.x + aHalfToolSize, iToolCenter.y - aHalfToolSize},
		{iToolCenter.x + aHalfToolSize, iToolCenter.y + aHalfToolSize},
		{iToolCenter.x - aHalfToolSize, iToolCenter.y + aHalfToolSize}
	};

	for (const auto& aCorner : aToolCorners)
	{
		if (!IsPointInsidePolygon(aCorner, iRegion))
		{
			return false;
		}
	}
	return true;
}

// Generate tool path within the region using raster scanning pattern
ToolPath GenerateToolPath(const BluePolygon& iRegion, double iToolSize)
{
	// Calculate bounding box of the region polygon
	double aMinX = iRegion[0].x, aMaxX = iRegion[0].x;
	double aMinY = iRegion[0].y, aMaxY = iRegion[0].y;
	for (const auto& aPoint : iRegion)
	{
		aMinX = std::min(aMinX, aPoint.x);
		aMaxX = std::max(aMaxX, aPoint.x);
		aMinY = std::min(aMinY, aPoint.y);
		aMaxY = std::max(aMaxY, aPoint.y);
	}

	ToolPath oPath;
	bool aMoveLeftToRight = true;

	for (double aY = aMinY + iToolSize / 2.0; aY <= aMaxY; aY += iToolSize)
	{
		if (aMoveLeftToRight)
		{
			for (double aX = aMinX + iToolSize / 2.0; aX <= aMaxX; aX += iToolSize)
			{
				ToolPathPoint aToolCenter(aX, aY);
				if (AreAllToolCornersInsideRegion(aToolCenter, iToolSize, iRegion))
				{
					oPath.push_back(aToolCenter);
				}
			}
		}
		else
		{
			for (double aX = aMaxX - iToolSize / 2.0; aX >= aMinX; aX -= iToolSize)
			{
				ToolPathPoint aToolCenter(aX, aY);
				if (AreAllToolCornersInsideRegion(aToolCenter, iToolSize, iRegion))
				{
					oPath.push_back(aToolCenter);
				}
			}
		}
		aMoveLeftToRight = !aMoveLeftToRight;
	}

	return oPath;
}
