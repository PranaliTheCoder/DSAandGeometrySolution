#ifndef TOOLPATH_H
#define TOOLPATH_H

#include <vector>

// Struct to represent a point in 2D space
struct ToolPathPoint
{
	double x;
	double y;

	ToolPathPoint() : x(0.0), y(0.0) {}
	ToolPathPoint(double iX, double iY) : x(iX), y(iY) {}
};

// Alias for polygon represented as a vector of points
using BluePolygon = std::vector<ToolPathPoint>;

// Alias for tool path represented as a vector of points
using ToolPath = std::vector<ToolPathPoint>;

// Returns true if a point is inside the polygon (ray casting)
bool IsPointInsidePolygon(const ToolPathPoint& iPoint, const BluePolygon& iPolygon);

// Returns true if all four corners of the square tool are inside the polygon
bool AreAllToolCornersInsideRegion(const ToolPathPoint& iToolCenter, double iToolSize, const BluePolygon& iRegion);

// Generates the raster tool path within the polygonal region
ToolPath GenerateToolPath(const BluePolygon& iRegion, double iToolSize);

#endif // TOOLPATH_H
