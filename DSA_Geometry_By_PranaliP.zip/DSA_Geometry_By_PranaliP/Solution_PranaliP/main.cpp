﻿#include <iostream>
#include <vector>
#include <tuple>
#include <sstream> 
#include "MazeSolver.h"
#include "StockMarketExample.h"
#include "BoundaryFillSolver.h"
#include "BooleanOperation.h"
#include "PointInsideOrNot.h"
#include "ToolPath.h"

using namespace std;
Polygon createSampleiPolygonA() 
{
	Polygon iPoly;

	// Outer contour (5 points)
	iPoly.outer =
	{
		{3.0, 0.5},   // First point
		{2.8, 9.0},   // Second point
		{7.0, 9.0},    // Third point
		{4.75, 5.0},    // Fourth point
		{9.0, 3.0}     // Fifth point
	};

	// First hole (4 points)
	iPoly.AddHole(
		{
		{3.5, 2.0},    // Hole1-1
		{5.5, 2.0},    // Hole1-2
		{5.5, 4.0},    // Hole1-3
		{3.5, 4.0}     // Hole1-4
		});

	// Second hole (3 points)
	iPoly.AddHole({
		{3.0, 6.5},   // Hole2-1
		{5.0, 6.5},    // Hole2-2
		{4.0, 8.0}     // Hole2-3
		});

	return iPoly;
}

Polygon createSampleiPolygonB()
{
	Polygon iPoly;

	// Outer contour (4 points)
	iPoly.outer = 
	{
		{1.0, 1.0},    // Point 1
		{4.5, 6.25},    // Point 2
		{1.5, 8.5},    // Point 3
		{7.5, 6.5}     // Point 4
	};

	iPoly.AddHole({
		{4.5, 4.5},   // Hole2-1
		{6, 5.5},    // Hole2-2
		{5.0, 6.0},     // Hole2-3
		{4.0, 5.0}
		});

	// No holes (as specified by "0\n")
	return iPoly;
}
void PrintToolPath(const ToolPath& path, const std::string& label)
{
	std::cout << label << " (" << path.size() << " steps):\n";
	for (const auto& pt : path)
	{
		std::cout << "(" << pt.x << ", " << pt.y << ")\n";
	}
	std::cout << std::endl;
}

int main()
{
	//----------------------------------------Maze Solver Problem----------------------------------------------------------------
	vector<vector<int>> aMazeGrid =
	{
		{0,0,0,0,0,0,0,1,1,0,0,0},
		{0,1,1,0,0,1,0,0,0,0,1,0},
		{0,0,1,0,1,1,0,0,1,0,0,1},
		{0,0,1,1,1,0,0,1,0,0,0,0},
		{0,0,0,0,0,0,0,1,0,1,0,0},
		{0,0,1,0,1,0,1,1,1,1,0,0},
		{0,0,1,1,1,0,0,0,0,0,0,1},
		{0,0,0,1,0,0,0,0,0,1,0,0},
		{1,1,0,0,0,1,1,1,1,1,0,0},
		{0,0,0,1,0,0,0,0,0,0,0,0}
	};


	pair<int, int> aStartPosition = make_pair(0, 0);
	pair<int, int> aGoalPosition = make_pair(9, 8);

	MazeSolver aSolver(aMazeGrid, aGoalPosition);
	vector<pair<int, int>> aSolutionPath;

	cout << "BFS Path:\n";
	if (aSolver.FindOptimalPathUsingBFS(aStartPosition, aGoalPosition, aSolutionPath))
		aSolver.PrintPath(aSolutionPath);
	else
		cout << "No path found using BFS.\n";


	cout << "A* Path:\n";
	aSolutionPath.clear();
	if (aSolver.FindOptimalPathUsingAStar(aStartPosition, aGoalPosition, aSolutionPath))
		aSolver.PrintPath(aSolutionPath);
	else
		cout << "No path found using A*.\n";


	/// ------------------------------------------BoundryFill Algorithm-------------------------
	{
		BoundaryFillSolver aBoundrySolver;
		std::string aMode;
		int aUserIndex = -1;

		std::cout << "Enter Mode (Row/Column/r/c): ";
		std::cin >> aMode;


		while (true)
		{
			std::cout << "Enter " << ((aMode == "row" || aMode == "r") ? "Row" : "Column") << " Number : ";
			std::cin >> aUserIndex;

			if (std::cin.fail() || aUserIndex <= 0)
			{
				std::cin.clear();
				std::cin.ignore(INT_MAX, '\n');
				std::cout << "Invalid input! Enter a positive number (1 or higher).\n";
			}
			else
			{
				break;
			}
		}

		std::vector<std::string> aUserGrid =
		{
			"  XXXXXX       ",
			"  X    X       ",
			"  X    XXXXX   ",
			"  X        X   ",
			"  XXXXXXXXXX   ",
			"               ",
			"  AAA   AAAAAAA",
			"  A A   A     A",
			"  A AAAAA     A",
			"  A           A",
			"  AAAAAAAAAAAAA"
		};
		aBoundrySolver.SetGrid(aUserGrid);
		aBoundrySolver.FillRowOrColumnBasedOnUserInput(aMode, aUserIndex);

		std::cout << "\nResulting Grid:\n";
		aBoundrySolver.DisplayGrid();
	}
	//--------------------------------------------------Stock Market Problem-------------------------------------------------------------------------------------------------------
	{
		// Input vector of daily returns for 20 days, including both profits and losses.
		std::vector<int> aDailyReturns = { 100, -30, -120, 10, 2, 16, 12, 14, -11, 0,-121, 34, 0, -200, 24, 54, 43, 0, 31, -13 };

		int oStartDay = 0;
		int oEndDay = 0;
		int oMaxProfitSum = 0;

		// Compute the maximum profit period.
		std::tie(oStartDay, oEndDay, oMaxProfitSum) = FindMaxConsecutiveProfitPeriod(aDailyReturns);

		// Display the results.
		std::cout << "Maximum profit of Rs." << oMaxProfitSum
			<< " Achieved from day " << oStartDay
			<< " To day " << oEndDay << std::endl;
	}
	//-------------------------------------------BooleanOperation---------------------------------------------------------
	Polygon A = createSampleiPolygonA();
	Polygon B = createSampleiPolygonB();

	cout << "-------UNION OPERATION (A+B)-----------\n";
	auto aUnionResult = PerformUnion(A, B);
	PrintResults(aUnionResult);

	cout << "\n--------SUBTRACT OPERATION (A - B)-------------\n";
	auto aSubtractResult = PerformSubtract(A, B);
	PrintResults(aSubtractResult);

	//---------------------------------------------PointInsideOrOutside---------------------------------------------------
	PolygonClassifier aClassifier;

	Polygone aOuter = { {1,1}, {1,4}, {4,4}, {4,1} };
	aClassifier.SetOuterPolygon(aOuter);

	Polygone aHole1 = { {2,2}, {3,1}, {3,3}, {2,3} };
	aClassifier.AddHole(aHole1);

	//Polygone aHole2 = { {6,5}, {9,5}, {9,2}, {6,2} };
	//aClassifier.AddHole(aHole2);

	// Test points
	std::vector<Point1> aTestPoints ={{2.5,2.5},  {1,3},  {4,4}, {11,5}, {1.5, 1.5} };

	for (const auto& aPt : aTestPoints) 
	{
		bool aInside = aClassifier.IsPointInside(aPt);
		std::cout << "Point (" << aPt.first << ", " << aPt.second << ") is "
			<< (aInside ? "INSIDE" : "OUTSIDE") << " The Given Polygon.\n";
	}
	std::cout << "\n\n";


	//---------------------------------------------ToolPathGenrator---------------------------------------------------

	BluePolygon aCutRegion = 
	{
		{0,0}, {10,0}, {10,10}, {0,10}
	};

	double aBigTool = 3.0;
	double aSmallTool = 1.0;

	ToolPath aBigToolPath = GenerateToolPath(aCutRegion, aBigTool);
	ToolPath aSmallToolPath = GenerateToolPath(aCutRegion, aSmallTool);

	PrintToolPath(aBigToolPath, "Big Tool Path (3x3)");
	PrintToolPath(aSmallToolPath, "Small Tool Path (1x1)");
	return 0;
}
