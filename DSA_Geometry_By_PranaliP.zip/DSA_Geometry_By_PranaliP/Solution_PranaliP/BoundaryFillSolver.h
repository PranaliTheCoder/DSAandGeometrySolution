// BoundaryFillSolver.h
#ifndef BOUNDARY_FILL_SOLVER_H
#define BOUNDARY_FILL_SOLVER_H

#include <vector>
#include <string>

class BoundaryFillSolver
{
public:
	BoundaryFillSolver();

	void FillRowOrColumnBasedOnUserInput(const std::string& iMode, int iNumber);

	void SetGrid(const std::vector<std::string>& iGrid)
	{
		mGrid = iGrid;
		mRowCount = static_cast<int>(mGrid.size());
		mColCount = static_cast<int>(mGrid[0].size());
	}

	void DisplayGrid() const;

private:
	std::vector<std::string> mGrid;   // the character grid
	int mRowCount;                    // number of rows
	int mColCount;                    // number of columns

	// Fill closed spans on row aRowIndex (0-based)
	void FillRow(int iRowIndex);

	// Fill closed spans on column aColIndex (0-based)
	void FillColumn(int iColIndex);
};

#endif 
