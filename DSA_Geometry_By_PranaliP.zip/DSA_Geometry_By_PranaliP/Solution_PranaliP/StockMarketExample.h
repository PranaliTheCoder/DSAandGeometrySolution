#pragma once
#ifndef STOCK_MARKET_EXAMPLE_H
#define STOCK_MARKET_EXAMPLE_H

#include <vector>
#include <tuple>

//////////////////////////////////////////////////////////////////////////
//Purpose: Finds the consecutive sequence of days with the maximum sum of profits.
// Algorithm to efficiently compute maximum subarray sum in O(n) time.
// Input:
// iDailyReturns - Vector of daily profit or loss values (can be positive, negative, or zero).
// Output:
// Returns a tuple with three values:
// oStartDay - 1-based index of the first day in the maximum profit sequence.
// oEndDay   - 1-based index of the last day in the maximum profit sequence.
// oMaxProfitSum - The maximum profit sum over that consecutive sequence.
//////////////////////////////////////////////////////////////////////////

std::tuple<int, int, int> FindMaxConsecutiveProfitPeriod(const std::vector<int>& iDailyReturns);

#endif // STOCK_MARKET_EXAMPLE_H
