#include <iostream>
#include <vector>
#include <queue>
#include <utility>
#include <algorithm>
#include <limits>
#include <cmath>
#include "MazeSolver.h"

using namespace std;

// Class to solve a The Maze Problem using BFS and A* Search

MazeSolver::MazeSolver(const vector<vector<int>>& iMazeGrid, pair<int, int> iGoalPosition)
	: mMazeGrid(iMazeGrid), mRowCount(static_cast<int>(iMazeGrid.size())), mColCount(static_cast<int>(iMazeGrid[0].size())), mGoalPosition(iGoalPosition)
{
	// Precompute the Manhattan-distance heuristic from every cell to the goal	& fill heuristic table 
	mHeuristicTable.resize(mRowCount, vector<int>(mColCount, 0));
	for (int aRow = 0; aRow < mRowCount; ++aRow)
	{
		for (int aCol = 0; aCol < mColCount; ++aCol)
		{
			mHeuristicTable[aRow][aCol] = abs(aRow - mGoalPosition.first) + abs(aCol - mGoalPosition.second);
		}
	}
}

// BFS-> to find the unweighted shortest path
bool MazeSolver::FindOptimalPathUsingBFS(pair<int, int> iStartPosition, pair<int, int> iGoalPosition, vector<pair<int, int>>& oPath)
{
	static const vector<pair<int, int>> aStepOffsets =
	{
		{-1, 0}, {1, 0}, {0, -1}, {0, 1}
	};

	// To track visited cells
	vector<vector<bool>> aVisitedCells(mRowCount, vector<bool>(mColCount, false));

	// To store the parent of each cell we came from
	vector<vector<pair<int, int>>> aParentOf(mRowCount, vector<pair<int, int>>(mColCount, make_pair(-1, -1)));

	queue<pair<int, int>> aCellsToVisitQueue;
	aCellsToVisitQueue.push(iStartPosition);
	aVisitedCells[iStartPosition.first][iStartPosition.second] = true;

	while (!aCellsToVisitQueue.empty())
	{
		pair<int, int> aCurrentPosition = aCellsToVisitQueue.front();
		aCellsToVisitQueue.pop();

		if (aCurrentPosition == iGoalPosition)
		{
			ReconstructThePath(iStartPosition, aCurrentPosition, aParentOf, oPath);
			return true;
		}

		for (size_t i = 0; i < aStepOffsets.size(); ++i)
		{
			int aNeighborRow = aCurrentPosition.first + aStepOffsets[i].first;
			int aNeighborCol = aCurrentPosition.second + aStepOffsets[i].second;

			if (IsCellValid(aNeighborRow, aNeighborCol, aVisitedCells))
			{
				aVisitedCells[aNeighborRow][aNeighborCol] = true;
				aParentOf[aNeighborRow][aNeighborCol] = aCurrentPosition;
				aCellsToVisitQueue.push(make_pair(aNeighborRow, aNeighborCol));
			}
		}
	}
	return false;
}

// A*: finds an optimal path using g + h
bool MazeSolver::FindOptimalPathUsingAStar(pair<int, int> iStartPosition, pair<int, int> iGoalPosition, vector<pair<int, int>>& oPath)
{
	typedef pair<int, pair<int, int>> AStarNode;  // (F Score, position)

	// G Score = cost from start to each cell
	vector<vector<int>> aCostFromStart(mRowCount, vector<int>(mColCount, INT_MAX));
	// Closed set = cells whose best costFromStart is final
	vector<vector<bool>> aClosedCells(mRowCount, vector<bool>(mColCount, false));
	// Track parents for reconstructing path
	vector<vector<pair<int, int>>> aParentOf(mRowCount, vector<pair<int, int>>(mColCount, make_pair(-1, -1)));

	priority_queue<AStarNode, vector<AStarNode>, greater<AStarNode>> aExplorationQueue;
	aCostFromStart[iStartPosition.first][iStartPosition.second] = 0;
	int aStartFScore = mHeuristicTable[iStartPosition.first][iStartPosition.second];
	aExplorationQueue.push(make_pair(aStartFScore, iStartPosition));

	static const vector<pair<int, int>> aStepOffsets =
	{
		{-1, 0}, {1, 0}, {0, -1}, {0, 1}
	};

	while (!aExplorationQueue.empty())
	{
		AStarNode aTopNode = aExplorationQueue.top();
		aExplorationQueue.pop();

		pair<int, int> aCurrentPosition = aTopNode.second;

		if (aClosedCells[aCurrentPosition.first][aCurrentPosition.second])
			continue;

		aClosedCells[aCurrentPosition.first][aCurrentPosition.second] = true;

		if (aCurrentPosition == iGoalPosition)
		{
			ReconstructThePath(iStartPosition, aCurrentPosition, aParentOf, oPath);
			return true;
		}

		for (size_t i = 0; i < aStepOffsets.size(); ++i)
		{
			int aNeighborRow = aCurrentPosition.first + aStepOffsets[i].first;
			int aNeighborCol = aCurrentPosition.second + aStepOffsets[i].second;

			if (IsCellBlocked(aNeighborRow, aNeighborCol) || aClosedCells[aNeighborRow][aNeighborCol])
			{
				continue;
			}

			int aTentativeGScore = aCostFromStart[aCurrentPosition.first][aCurrentPosition.second] + 1;

			if (aTentativeGScore < aCostFromStart[aNeighborRow][aNeighborCol])
			{
				aCostFromStart[aNeighborRow][aNeighborCol] = aTentativeGScore;
				aParentOf[aNeighborRow][aNeighborCol] = aCurrentPosition;

				int aNewFScore = aTentativeGScore + mHeuristicTable[aNeighborRow][aNeighborCol];

				aExplorationQueue.push(make_pair(aNewFScore, make_pair(aNeighborRow, aNeighborCol)));
			}
		}
	}

	return false;  // no path found
}

// Ensure cell is in bounds, free, and not yet visited
bool MazeSolver::IsCellValid(int aRow, int aCol,
	const vector<vector<bool>>& iVisited) const
{
	return aRow >= 0 && aRow < mRowCount&&
		aCol >= 0 && aCol < mColCount&&
		mMazeGrid[aRow][aCol] == 0 &&
		!iVisited[aRow][aCol];
}

// True if cell is out of bounds or blocked
bool MazeSolver::IsCellBlocked(int aRow, int aCol) const
{
	return aRow < 0 || aRow >= mRowCount ||
		aCol < 0 || aCol >= mColCount ||
		mMazeGrid[aRow][aCol] == 1;
}

// Backtrack from goal to start using the parent map
void MazeSolver::ReconstructThePath(pair<int, int> iStartPos, pair<int, int> iCurrentPos,
	const vector<vector<pair<int, int>>>& iParentOf, vector<pair<int, int>>& oPath) const
{
	pair<int, int> aTracePos = iCurrentPos;
	while (aTracePos != iStartPos)
	{
		oPath.push_back(aTracePos);
		aTracePos = iParentOf[aTracePos.first][aTracePos.second];
	}
	oPath.push_back(iStartPos);
	reverse(oPath.begin(), oPath.end());
}


// Print the solution path  
void MazeSolver::PrintPath(const vector<pair<int, int>>& iPath)
{
	for (size_t aIdx = 0; aIdx < iPath.size(); ++aIdx)
	{
		cout << "(" << iPath[aIdx].first << "," << iPath[aIdx].second << ") ";
	}
	cout << endl;
	cout << endl;
}

//int main()
//{
//
//	vector<vector<int>> aMazeGrid =
//	{
//		{0,0,0,0,0,0,0,1,1,0,0,0},
//		{0,1,1,0,0,1,0,0,0,0,1,0},
//		{0,0,1,0,1,1,0,0,1,0,0,1},
//		{0,0,1,1,1,0,0,1,0,0,0,0},
//		{0,0,0,0,0,0,0,1,0,1,0,0},
//		{0,0,1,0,1,0,1,1,1,1,0,0},
//		{0,0,1,1,1,0,0,0,0,0,0,1},
//		{0,0,0,1,0,0,0,0,0,1,0,0},
//		{1,1,0,0,0,1,1,1,1,1,0,0},
//		{0,0,0,1,0,0,0,0,0,0,0,0}
//	};
//
//
//	pair<int, int> aStartPosition = make_pair(0, 0);
//	pair<int, int> aGoalPosition = make_pair(9, 8);
//
//	MazeSolver aSolver(aMazeGrid, aGoalPosition);
//
//	MazeSolver aSolver(aMazeGrid, aGoalPosition);
//	vector<pair<int, int>> aSolutionPath;
//
//
//	cout << "BFS Path:\n";
//	if (aSolver.FindOptimalPathUsingBFS(aStartPosition, aGoalPosition, aSolutionPath))
//		aSolver.PrintPath(aSolutionPath);
//	else
//		cout << "No path found by BFS.\n";
//
//
//	cout << "A* Path:\n";
//	aSolutionPath.clear();
//	if (aSolver.FindOptimalPathUsingAStar(aStartPosition, aGoalPosition, aSolutionPath))
//		aSolver.PrintPath(aSolutionPath);
//	else
//		cout << "No path found by A*.\n";
//
//	return 0;
//}
