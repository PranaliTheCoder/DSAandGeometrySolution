#include "PointInsideOrNot.h"
#include <vector>

void PolygonClassifier::SetOuterPolygon(const Polygone& iOuter)
{
	mOuterPolygon = iOuter;
}

void PolygonClassifier::AddHole(const Polygone& iHole)
{
	mHoles.push_back(iHole);
}

bool PolygonClassifier::IsPointInside(const Point1& iPoint) const
{
	if (!IsPointInPolygon(iPoint, mOuterPolygon))
	{
		return false;
	}
	for (const auto& mHoles : mHoles)
	{
		if (IsPointInPolygon(iPoint, mHoles))
		{
			return false;
		}
	}
	return true;
}

// Ray casting algorithm
bool PolygonClassifier::IsPointInPolygon(const Point1& iPoint, const Polygone& iPoly) const
{
	int aCrossings = 0;
	size_t n = iPoly.size();
	for (size_t i = 0; i < n; ++i) 
	{
		const Point1& a = iPoly[i];
		const Point1& b = iPoly[(i + 1) % n];

		if ((a.second > iPoint.second) != (b.second > iPoint.second)) 
		{
			double atX = (b.first - a.first) * (iPoint.second - a.second) / (b.second - a.second) + a.first;
			if (iPoint.first < atX)
			{
				++aCrossings;
			}
		}
	}
	return (aCrossings % 2) == 1;
}
